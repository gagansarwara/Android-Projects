package com.example.alarmmessagedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

public class Alarm extends AppCompatActivity {

    EditText time;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alarm);

        time = (EditText) findViewById(R.id.txt_time);
    }

    public void startAlert(View view) {

        int i = Integer.parseInt(time.getText().toString());
        Intent intent = new Intent(this,AlarmBroadcastReceiver.class);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(this.getApplicationContext(),12345,intent,0);

        AlarmManager alarmManager = (AlarmManager) getSystemService(ALARM_SERVICE);

        alarmManager.set(AlarmManager.RTC_WAKEUP,System.currentTimeMillis() + (i * 1000),pendingIntent);

        Toast.makeText(this, "Alarm set in : " + i + " seconds", Toast.LENGTH_LONG).show();
    }
}
