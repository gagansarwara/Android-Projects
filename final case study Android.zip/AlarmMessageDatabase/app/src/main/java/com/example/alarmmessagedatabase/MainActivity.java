package com.example.alarmmessagedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {

    Button alarmbtn;
    Button messagebtn;
    Button profilebtn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        getSupportActionBar().setTitle("My Case Study App");

        alarmbtn = (Button) findViewById(R.id.alarm_btn); //For Alarm btn
        messagebtn = (Button) findViewById(R.id.msg_btn); //For Message btn
        profilebtn = (Button) findViewById(R.id.profile_btn); //For profile btn

        alarmbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Alarm.class);
                startActivity(i);
            }
        });


        messagebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,Message.class);
                startActivity(i);
            }
        });


        profilebtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent(MainActivity.this,LoginPage.class);
                startActivity(i);
            }
        });


    }
}
