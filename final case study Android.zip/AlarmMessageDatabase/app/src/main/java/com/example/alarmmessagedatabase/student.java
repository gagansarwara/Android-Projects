package com.example.alarmmessagedatabase;

public class student {

    public String Username,Email,Gender;

    public student() {
    }

    public student(String username, String email, String gender){
        Username = username;
        Email = email;
        Gender = gender;

    }

}
