package com.example.alarmmessagedatabase;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.RadioButton;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
public class SignupPage extends AppCompatActivity {
    EditText txt_username, txt_email, txt_password, txt_conPassword;
    RadioButton radioGenderMale, radioGenderFemale;
    Button btn_register;
    ProgressBar progressBar;
    DatabaseReference databaseReference;
    String gender = "";
    FirebaseAuth firebaseAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_signup_page);
        getSupportActionBar().setTitle("Registration Form");

        txt_username = (EditText) findViewById(R.id.username);
        txt_email = (EditText) findViewById(R.id.email);
        txt_password = (EditText) findViewById(R.id.password);
        txt_conPassword = (EditText) findViewById(R.id.conpassword);
        btn_register = (Button)findViewById(R.id.register_btn);

        progressBar = (ProgressBar) findViewById(R.id.progressBar);
        radioGenderMale = (RadioButton) findViewById(R.id.male);
        radioGenderFemale = (RadioButton) findViewById(R.id.female);

        databaseReference = FirebaseDatabase.getInstance().getReference("Student");
        firebaseAuth = FirebaseAuth.getInstance(); //to get the current instance of Firebase

        btn_register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                final String userName = txt_username.getText().toString();
                final String email = txt_email.getText().toString();
                String password = txt_password.getText().toString();
                String conPassword = txt_conPassword.getText().toString();

                if(radioGenderMale.isChecked()){
                    gender = "Male";
                }

                if(radioGenderFemale.isChecked()){
                    gender = "Female";
                }

                if(TextUtils.isEmpty(userName)){
                    Toast.makeText(SignupPage.this, "Please Enter Username", Toast.LENGTH_SHORT).show();
                }

                if(TextUtils.isEmpty(email)){
                    Toast.makeText(SignupPage.this, "Please Enter Email", Toast.LENGTH_SHORT).show();
                }

                if(TextUtils.isEmpty(password)){
                    Toast.makeText(SignupPage.this, "Please Enter Password", Toast.LENGTH_SHORT).show();
                }

                if(TextUtils.isEmpty(conPassword)){
                    Toast.makeText(SignupPage.this, "Please Enter Confirm Password", Toast.LENGTH_SHORT).show();
                }

                if (password.length()<6){
                    Toast.makeText(SignupPage.this, "Password too short", Toast.LENGTH_SHORT).show();
                }

                progressBar.setVisibility(View.VISIBLE);

                if (password.equals(conPassword)){

                    firebaseAuth.createUserWithEmailAndPassword(email, password)
                            .addOnCompleteListener(SignupPage.this, new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {

                                    progressBar.setVisibility(View.GONE);
                                    if (task.isSuccessful()) {
                                        student information = new student(userName,email,gender);

                                        FirebaseDatabase.getInstance().getReference("Student")
                                                .child(FirebaseAuth.getInstance().getCurrentUser().getUid())
                                                .setValue(information).addOnCompleteListener(new OnCompleteListener<Void>() {
                                            @Override
                                            public void onComplete(@NonNull Task<Void> task) {

                                                Intent i = new Intent(SignupPage.this,Registration_Successfull.class);
                                                startActivity(i);
                                                Toast.makeText(SignupPage.this, "Registration Successful", Toast.LENGTH_SHORT).show();
                                            }
                                        });
                                    }

                                    else {

                                        Toast.makeText(SignupPage.this, "Registration Failed ", Toast.LENGTH_SHORT).show();
                                    }

                                }
                            });
                }
            }
        });

    }
}
