package com.example.alarmmessagedatabase;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import java.util.Locale;

public class Registration_Successfull extends AppCompatActivity {

    EditText textSpeech;
    Button   btn_speechText;
    TextToSpeech toSpeech;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration__successfull);

        textSpeech = (EditText) findViewById(R.id.TextForSpeech);
        btn_speechText = (Button) findViewById(R.id.btn_speech);

        toSpeech = new TextToSpeech(getApplicationContext(), new TextToSpeech.OnInitListener() {
            @Override
            public void onInit(int status) {

                if(status != TextToSpeech.ERROR){
                    toSpeech.setLanguage(Locale.CANADA);
                }
            }
        });

        btn_speechText.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                toSpeech.speak(textSpeech.getText().toString(), TextToSpeech.QUEUE_FLUSH,null);
            }
        });
    }
}
