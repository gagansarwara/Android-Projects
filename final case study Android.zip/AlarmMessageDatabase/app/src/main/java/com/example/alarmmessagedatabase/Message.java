package com.example.alarmmessagedatabase;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.telephony.SmsManager;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class Message extends AppCompatActivity {

    EditText txt_pNumber , txt_message ;
    Button btn_send;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_message);

        txt_pNumber = (EditText) findViewById(R.id.txt_phone_number);
        txt_message = (EditText) findViewById(R.id.txt_message);
        btn_send =  (Button) findViewById(R.id.send_button);
    }


    public void btn_send(View view) {
        /* HERE WE ARE CHECKING THE PERMISSION  */
        int permissioncheck = ContextCompat.checkSelfPermission(this, Manifest.permission.SEND_SMS);
        if (permissioncheck == PackageManager.PERMISSION_GRANTED) {
            MyMessage();

        }

        else
        {
            /* TO REQUEST THE PERMISSION AGAIN WE WILL USE THE FOLLOWING CODE */
            ActivityCompat.requestPermissions(this, new String[] { Manifest.permission.SEND_SMS},0);
        }
    }

    private void MyMessage() {

        /* Variables declaration and Values assignment to variables */
        String phoneNumber = txt_pNumber.getText().toString().trim();
        String message = txt_message.getText().toString().trim();

        if (!txt_pNumber.getText().toString().equals("") || !txt_message.getText().toString().equals("")) {

            SmsManager smsManager = SmsManager.getDefault();
            smsManager.sendTextMessage(phoneNumber, null, message, null, null);

            Toast.makeText(this, "Message Sent to : " + phoneNumber, Toast.LENGTH_SHORT).show();

        }

        else
        {
            Toast.makeText(this, " Please Enter Number and Message both", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        switch (requestCode)
        {
            case 0 :
                if(grantResults.length >=0 && grantResults[0] == PackageManager.PERMISSION_GRANTED)
                {
                    MyMessage();
                }

                else
                {
                    Toast.makeText(this, " You didn't get the required permission", Toast.LENGTH_SHORT).show();
                }
        }

    }

}


